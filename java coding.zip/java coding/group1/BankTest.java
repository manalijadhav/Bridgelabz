
//testing entity
class BankTest
{
	public static void main(String args[])
	{
		System.out.println("starting the bank....");
		BankAccount bankObj1 = new BankAccount();
		BankAccount bankObj2 = new BankAccount();
		BankAccount bankObj3 = new BankAccount();



		
		

		/*bankObj1.setBankAccount(101,"Julie",50000);
		bankObj1.showBankAccount();

		bankObj1.withdraw(6000);
		bankObj1.showBankAccount();

		bankObj1.deposit(4000);
		bankObj1.showBankAccount();
		*/
			

		bankObj1.setBankAccount(101,"Julie",50000);
		bankObj2.setBankAccount(102,"Robert",30000);
		bankObj3.setBankAccount(103,"Jack",60000);

		bankObj1.withdraw(2000);
		bankObj2.withdraw(4000);
		bankObj3.withdraw(4500);

		
		bankObj1.deposit(2000);
		bankObj2.deposit(1500);
		bankObj3.deposit(3000);


		bankObj1.showBankAccount();
		bankObj2.showBankAccount();
		bankObj3.showBankAccount();

				


	}
}
// business entity
class BankAccount
{
	int accountNumber; String accountHolder; double accountBalance;

	void withdraw(double amountToWithdraw)	{
		System.out.println("Withdrawing......"+amountToWithdraw);
		accountBalance = accountBalance - amountToWithdraw;
	}
	void deposit(double amountToDeposit) {
		System.out.println("Depositing......"+amountToDeposit);
		accountBalance = accountBalance + amountToDeposit;
	}
	void setBankAccount(int acno, String achn, double accBal) {
		System.out.println("Setting BankAccount....");
		accountNumber = acno;	accountHolder = achn;
		accountBalance = accBal;
	}
	void showBankAccount() {
		System.out.println("Account Number  : "+accountNumber);
		System.out.println("Account Holder  : "+accountHolder);
		System.out.println("Account Balance : "+accountBalance);
	}
}
