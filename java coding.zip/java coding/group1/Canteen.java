
//testing entity
class CanteenTable
{
	public static void main(String args[])
	{
		System.out.println("Opening the Canteen....");
		Canteen canteenObj1 = new Canteen();
		Canteen canteenObj2 = new Canteen();
		Canteen canteenObj3 = new Canteen();
		

		/*canteenObj1.setCanteen(101,"Julie",50000);
		canteenObj1.showCanteen();

		canteenObj1.sold(600);
		canteenObj1.showCanteen();

		canteenObj1.restock(400);
		canteenObj1.showCanteen();
		*/
			

		canteenObj1.setCanteen(101,"Pattiesssss...",1000);
		canteenObj2.setCanteen(102,"Burggeerrr..",2000);
		canteenObj3.setCanteen(103,"Pizzaaaa...",1500);

		canteenObj1.showCanteen();
		canteenObj2.showCanteen();
		canteenObj3.showCanteen();



		System.out.println("");
	
		canteenObj1.sold(200);
		canteenObj2.sold(400);
		canteenObj3.sold(450);


		System.out.println("");
		
		canteenObj1.restock(200);
		canteenObj2.restock(150);
		canteenObj3.restock(300);


		System.out.println("");

		canteenObj1.showCanteen();
		canteenObj2.showCanteen();
		canteenObj3.showCanteen();


		System.out.println("");
				
	}
}
// business entity
class Canteen
{
	int itemNumber; String itemName; double itemStock;

	void sold(double amountTosold)	{
		System.out.println("sold......"+amountTosold);
		itemStock =itemStock  - amountTosold;
	}
	void restock(double amountTorestock) {
		System.out.println("restocking......"+amountTorestock);
		itemStock = itemStock + amountTorestock;
	}
	void setCanteen(int acno, String achn, double accBal) {
		System.out.println("Stocking Canteen....");
		itemNumber = acno;
		itemName = achn;
		itemStock = accBal;
	}
	void showCanteen() {
		System.out.println("");
		System.out.println("Item Number  : "+itemNumber);
		System.out.println("Item Name  : "+itemName);
		System.out.println("Item left in stock : "+itemStock);
		System.out.println("");
	}
}
