class Grocery
{
	String item_name;
	int item_price;
	int quantity;
	int total_price;

void show_items()
{
	System.out.println("Name of the item : " +item_name);
	System.out.println("Price of the item : " +item_price);
	System.out.println("Quantity of the item : " +quantity);
	System.out.println("Total Price of the item : " +total_price);
	System.out.println("========================");
}

void cart (String itemname, int price, int quant,int tot)
{
	System.out.println("===List of items===");
	item_name = itemname;
	item_price = price;
	quantity = quant;
	//total_price = tot;
}
void Bill(int item_quantity)
{
	total_price = item_quantity*item_price;
	System.out.println("Total price of the item =" +total_price);
}
}
class Shop
{
	public static void main(String args[])
	{
		System.out.println("Welcome to our shop");
		Grocery grossObj1= new Grocery();
		Grocery grossObj2= new Grocery();
		Grocery grossObj3= new Grocery();
		
		grossObj1.show_items();
		grossObj2.show_items();
		grossObj3.show_items();

		grossObj1.cart("Basmati Rice", 150 ,100);
		grossObj2.cart("Sugar", 40 ,20 );
		grossObj3.cart("Pulses", 100 ,50 );

		grossObj1.show_items();
		grossObj2.show_items();
		grossObj3.show_items();
		
		grossObj1.Bill(20);
		grossObj2.Bill(20);
		grossObj3.Bill(20);
		
		grossObj1.show_items();
		grossObj2.show_items();
		grossObj3.show_items();

		}
}