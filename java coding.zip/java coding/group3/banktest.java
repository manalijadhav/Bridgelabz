class banktest
{

	public static void main(String []args)
	{
		bank b =new bank();

		bank b1=new bank();

		bank b2 =new bank();
		b.display();
		b1.display();
		b2.display();


		b.setAccBal(101,"abc",5000.0);
		b1.setAccBal(102,"def",6000.0);
		b2.setAccBal(103,"pqr",7000.0);

		b.display();
		b1.display();
		b2.display();		

		b.deposite(2000);
		b1.deposite(2000);
		b2.deposite(2000);

		b.display();
		b1.display();
		b2.display();

		b.withdraw(1000);
		b1.withdraw(1000);
		b2.withdraw(1000);
		b.display();
		b1.display();
		b2.display();
		
	}
}

class bank
{
	int accountnumber;
	String accountname;
	double accbalance;
	
	void withdraw(double amtToWithdraw)
	{
	 	System.out.println("Withdrawing amt");
		accbalance=accbalance-amtToWithdraw;
	}

	void deposite(double amtToDeposite)
	{
	 	System.out.println("Depositing amt");
		accbalance=accbalance+amtToDeposite;
	}

	void setAccBal(int ach,String ahn, double ab)
	{
		System.out.println("Setting account");
		 accountnumber=ach;
		 accountname=ahn;
		 accbalance=ab;
		
	}
	void display()
	{
		System.out.println("number  "+accountnumber);
		System.out.println("name  "+accountname);
		System.out.println("bal  "+accbalance);


		System.out.println("--------------------------------------");
	}

}
